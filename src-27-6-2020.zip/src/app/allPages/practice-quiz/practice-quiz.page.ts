import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-practice-quiz',
  templateUrl: './practice-quiz.page.html',
  styleUrls: ['./practice-quiz.page.scss'],
})
export class PracticeQuizPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
