import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-shortquestions',
  templateUrl: './shortquestions.component.html',
  styleUrls: ['./shortquestions.component.scss'],
})
export class ShortquestionsComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
