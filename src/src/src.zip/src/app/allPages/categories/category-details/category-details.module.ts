import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { CategoryDetailsPageRoutingModule } from './category-details-routing.module';

import { CategoryDetailsPage } from './category-details.page';
import { SubcategoryComponent } from 'src/app/components/allcategories/subcategory/subcategory.component';
import { PracticeQuestionService } from 'src/app/allServices/practice-question.service';
import { PracticeQuestionComponent } from 'src/app/components/practice-question/practice-question.component';
import { PracticeQuizComponent } from 'src/app/components/practice-quiz/practice-quiz.component';
import { PracticeQuizService } from 'src/app/allServices/practice-quiz.service';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    CategoryDetailsPageRoutingModule
  ],
  declarations: [CategoryDetailsPage, SubcategoryComponent, PracticeQuestionComponent, PracticeQuizComponent],
  providers: [PracticeQuestionService, PracticeQuizService]
})
export class CategoryDetailsPageModule {}
