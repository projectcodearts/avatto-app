import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class PracticeQuestionService {

  constructor(private http:HttpClient) { }

  getPQSdata(){
    return [
      {
        icon: "assets/images/p-f-i.png",
        name: "Practice Question",
        subname:"UGC NET PAPER 1",
        link:"#"
      }

    ]
  }
}
