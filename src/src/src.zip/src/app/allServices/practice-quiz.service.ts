import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class PracticeQuizService {

  constructor(private http:HttpClient) { }
  getQuizdata(){
    return [
      {
        icon: "assets/images/p-f-q.png",
        name: "Practice Quiz",
        subname:"UGC NET PAPER 1",
        link:"#"
      }

    ]
  }
}
