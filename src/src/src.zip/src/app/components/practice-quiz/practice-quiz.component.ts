import { Component, OnInit } from '@angular/core';
import { PracticeQuizService } from 'src/app/allServices/practice-quiz.service';

@Component({
  selector: 'app-practice-quiz',
  templateUrl: './practice-quiz.component.html',
  styleUrls: ['./practice-quiz.component.scss'],
})
export class PracticeQuizComponent implements OnInit {
  fetching = false;
  quizdata: any;
  constructor(private _subcatquiz: PracticeQuizService) { }

  ngOnInit() {
    this.fetching = true;
    this.quizdata=this._subcatquiz.getQuizdata();
    this.fetching = false;
  }

}
