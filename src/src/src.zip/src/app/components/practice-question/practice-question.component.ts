import { Component, OnInit } from '@angular/core';
import { PracticeQuestionService } from 'src/app/allServices/practice-question.service';

@Component({
  selector: 'app-practice-question',
  templateUrl: './practice-question.component.html',
  styleUrls: ['./practice-question.component.scss'],
})
export class PracticeQuestionComponent implements OnInit {
  fetching = false;
  pqdata: any;
  constructor(private _subcatquestion: PracticeQuestionService) { }

  ngOnInit() {
    this.fetching = true;
    this.pqdata=this._subcatquestion.getPQSdata();
    this.fetching = false;
  }


}
