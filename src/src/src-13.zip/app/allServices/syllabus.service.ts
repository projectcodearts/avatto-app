import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { LoadingController } from '@ionic/angular';
@Injectable({
  providedIn: 'root'
})
export class SyllabusService {

  constructor(private http:HttpClient,public loadingController: LoadingController) { }
  public getsyllabus():Observable<object>{

    return this.http.get("http://avatto.in/wp-json/avatto/v2/featuredsyllabus");
   
  }
}
