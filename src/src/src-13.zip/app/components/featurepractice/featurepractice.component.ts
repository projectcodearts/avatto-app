import { Component, OnInit } from '@angular/core';
import { CategoryService } from 'src/app/service/category.service';
import { LoadingController } from '@ionic/angular';
import { finalize } from 'rxjs/operators';

@Component({
  selector: 'app-featurepractice',
  templateUrl: './featurepractice.component.html',
  styleUrls: ['./featurepractice.component.scss'],
})
export class FeaturepracticeComponent implements OnInit {

  featurePractices: any = []; 
  error:string;
  loading: any;

  constructor(private practice:CategoryService,public loadingController:LoadingController) { }

  ngOnInit() {
    this.ionViewWillEnter();
  }

  async presentLoading() {
    // Prepare a loading controller
    this.loading = await this.loadingController.create({
        message: 'Loading...'
    });
    // Present the loading controller
  await this.loading.present();
}

async ionViewWillEnter() {
  await this.presentLoading();

  // Load the data
  this.practice.getPractice().pipe(
    finalize(async () => {
        // Hide the loading spinner on success or error
        await this.loading.dismiss();
    })
)
.subscribe(data=>{
    
    const demo = JSON.stringify(data)
    this.featurePractices = (JSON.parse(demo));
  },
  err => {
    // Set the error information to display in the template
    this.error = 'An error occurred, the data could not be retrieved:';
  }
  );
}

}
