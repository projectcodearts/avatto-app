import { Component, OnInit } from '@angular/core';
import { CategoryServicesService } from '../../allServices/category-services.service';
import { LoadingController } from '@ionic/angular';
import { finalize } from 'rxjs/operators';
@Component({
  selector: 'app-featured-category',
  templateUrl: './featured-category.component.html',
  styleUrls: ['./featured-category.component.scss'],
})
export class FeaturedCategoryComponent implements OnInit {

 
  fcategory: any = []; 
  error:string;
  loading: any;
  constructor(private featuredCat: CategoryServicesService,public loadingController: LoadingController) { }

  ngOnInit() {
    this.ionViewWillEnter();
  }

  async presentLoading() {
    // Prepare a loading controller
    this.loading = await this.loadingController.create({
        message: 'Loading...'
    });
    // Present the loading controller
  await this.loading.present();
}

async ionViewWillEnter() {
  await this.presentLoading();

  // Load the data
  this.featuredCat.getfeaturedCategory().pipe(
    finalize(async () => {
        // Hide the loading spinner on success or error
        await this.loading.dismiss();
    })
)
.subscribe(data=>{
    
    const demo = JSON.stringify(data)
    this.fcategory = data;
  },
  err => {
    // Set the error information to display in the template
    this.error = 'An error occurred, the data could not be retrieved:';
  }
  );
}

}
