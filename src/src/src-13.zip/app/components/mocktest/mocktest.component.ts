import { Component, OnInit } from '@angular/core';
import { MocktestService } from 'src/app/allServices/mocktest.service';

@Component({
  selector: 'app-mocktest',
  templateUrl: './mocktest.component.html',
  styleUrls: ['./mocktest.component.scss'],
})
export class MocktestComponent implements OnInit {
  title: string = "Mock Test";
  mocktest: any;
  constructor(private _mocktest: MocktestService) { }

  ngOnInit() {
    this.mocktest=this._mocktest.getmocktest();
  }

}
