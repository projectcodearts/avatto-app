import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-eligiblity',
  templateUrl: './eligiblity.component.html',
  styleUrls: ['./eligiblity.component.scss'],
})
export class EligiblityComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
