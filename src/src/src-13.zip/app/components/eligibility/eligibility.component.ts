import { Component, OnInit } from '@angular/core';
import { CategoryService } from 'src/app/service/category.service';
import { LoadingController } from '@ionic/angular';
import { finalize } from 'rxjs/operators';
@Component({
  selector: 'app-eligibility',
  templateUrl: './eligibility.component.html',
  styleUrls: ['./eligibility.component.scss'],
})
export class EligibilityComponent implements OnInit {

  slideOpts = {
    slidesPerView: 10,
      freeMode: true,
      coverflowEffect: {
        rotate: 50,
        stretch: 0,
        depth: 100,
        modifier: 1,
        slideShadows: true,
      }
  };

  featureCategories: any = []; 
  error:string;
  loading: any;

  constructor(private category:CategoryService,public loadingController: LoadingController) { }

  ngOnInit() {
    this.ionViewWillEnter();
  }
  async presentLoading() {
    // Prepare a loading controller
    this.loading = await this.loadingController.create({
        message: 'Loading...'
    });
    // Present the loading controller
  await this.loading.present();
}
async ionViewWillEnter() {
    await this.presentLoading();

    // Load the data
    this.category.getData().pipe(
      finalize(async () => {
          // Hide the loading spinner on success or error
          await this.loading.dismiss();
      })
  )
  .subscribe(data=>{
      
      const demo = JSON.stringify(data)
      this.featureCategories = (JSON.parse(demo));
    },
    err => {
      // Set the error information to display in the template
      this.error = 'An error occurred, the data could not be retrieved:';
    }
    );
  }

}
