import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-entrypoint',
  templateUrl: './entrypoint.page.html',
  styleUrls: ['./entrypoint.page.scss'],
})
export class EntrypointPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
