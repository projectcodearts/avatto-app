import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class PapersService {

  constructor() { }
  getpapers(){
    return [
      {
        icon: "assets/images/p-i1.png",
        link: "#",
        name: "Paper_1"
      },
      {
        icon: "assets/images/p-i2.png",
        link: "#",
        name: "Paper_2"
      },
      {
        icon: "assets/images/p-i3.png",
        link: "#",
        name: "Paper_3"
      },
      {
        icon: "assets/images/p-i4.png",
        link: "#",
        name: "Paper_4"
      },
      {
        icon: "assets/images/p-i1.png",
        link: "#",
        name: "Paper_1"
      },
      {
        icon: "assets/images/p-i2.png",
        link: "#",
        name: "Paper_2"
      },
      {
        icon: "assets/images/p-i3.png",
        link: "#",
        name: "Paper_3"
      },
      {
        icon: "assets/images/p-i4.png",
        link: "#",
        name: "Paper_4"
      }
      
      
    ]
  }
}
