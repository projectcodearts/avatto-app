import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CommonService {

  
  constructor() { }
  getLogo(){
    return [
      {
        img:"assets/images/avatto-web-white.png"
      }
    ]
  }
}
