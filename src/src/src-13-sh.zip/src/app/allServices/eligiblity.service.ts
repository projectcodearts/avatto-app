import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class EligiblityService {

  constructor() { }
  geteligiblity(){
    return [
      {
        icon: "assets/images/eli-i1.png",
        link: "#",
        name: "Eligiblity_1",
        excerpt: "There are many variations"
      },
      {
        icon: "assets/images/eli-i2.png",
        link: "#",
        name: "Eligiblity_2",
        excerpt: "There are many variations"
      },
      {
        icon: "assets/images/eli-i3.png",
        link: "#",
        name: "Eligiblity_3",
        excerpt: "There are many variations"
      },
      {
        icon: "assets/images/eli-i1.png",
        link: "#",
        name: "Eligiblity_4",
        excerpt: "There are many variations"
      },
      {
        icon: "assets/images/eli-i2.png",
        link: "#",
        name: "Eligiblity_5",
        excerpt: "There are many variations"
      },
      {
        icon: "assets/images/eli-i3.png",
        link: "#",
        name: "Eligiblity_6",
        excerpt: "There are many variations"
      },
      
      
    ]
  }
}
