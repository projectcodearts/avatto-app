import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-entrypoint',
  templateUrl: './entrypoint.component.html',
  styleUrls: ['./entrypoint.component.scss'],
})
export class EntrypointComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
