import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';
import { EntrypointComponent } from './components/entrypoint/entrypoint.component';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'entrypoint',
    pathMatch: 'full'
  },
  {
    path: 'entrypoint',
    component: EntrypointComponent
  },
  {
    path: 'home',
    loadChildren: () => import('./allPages/home/home.module').then( m => m.HomePageModule)
  },
  {
    path: 'sign-in',
    loadChildren: () => import('./allPages/sign-in/sign-in.module').then( m => m.SignInPageModule)
  },
  {
    path: 'sign-up',
    loadChildren: () => import('./allPages/sign-up/sign-up.module').then( m => m.SignUpPageModule)
  },
  {
    path: 'dashboard',
    loadChildren: () => import('./allPages/dashboard/dashboard.module').then( m => m.DashboardPageModule)
  },
  
  
  
 
  
  
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule {}
