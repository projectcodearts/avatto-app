import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { LoadingController } from '@ionic/angular';
@Injectable({
  providedIn: 'root'
})
export class CategoryServicesService {
  constructor(private http:HttpClient,public loadingController: LoadingController) { }
  public getfeaturedCategory():Observable<object>{
    return this.http.get("https://avatto.in/wp-json/avatto/v2/featuredcat");
 }
 public getPractice():Observable<object>{
  return this.http.get("https://avatto.in/wp-json/avatto/v2/previouspaper/178");
}
  
}
