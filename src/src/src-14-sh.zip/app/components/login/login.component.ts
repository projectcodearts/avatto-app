import { Component, OnInit } from '@angular/core';
import { CommonService } from 'src/app/allServices/common.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
})
export class LoginComponent implements OnInit {

  mainlogo: string = "assets/images/avatto-web-white.png";
  
  login: { 
    email: string, 
    password: string,
    } = {
    email: '',
    password: '',
    };
  
  constructor() { }

  ngOnInit() {
   
  }
  logForm() {
    console.log(this.login);
  }

}
